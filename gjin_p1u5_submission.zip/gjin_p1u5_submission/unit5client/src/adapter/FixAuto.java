package adapter;

public interface FixAuto {

}

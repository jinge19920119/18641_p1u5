Project 1 - Unit 5    readme.txt

1.There are several 2 files in it, one is for client and one is for server. As usually, there are 2 class diagrams,2 input files in client and output for every step. 

2. class diagram.png is the class diagram of this unit. readFileProp.properties and readFileProp1.properties are two input files.

3. There are 2 new servlets and one new jsp file in client, in order to select car and configure car on the internet.


Following are the steps for this program:

1)Run the main method in the server.

2)Run the main method in the client. Type 1 to add cars, and then type in ’readFileProp.properties’ and ‘readFileProp1.properties’ to add these two files. Then type in ‘quit’ to quit this client.

3)Run the ChooseCar method in servlet package in the client. And choose model name, configure the car and show the result.


4. The three outcome pics are served in outcome file.

5. All the comments and explanations of the project has been written in the code as comments.
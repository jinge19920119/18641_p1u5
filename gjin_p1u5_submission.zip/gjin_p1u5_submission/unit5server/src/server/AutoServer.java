package server;

import java.util.Properties;


public interface AutoServer { 
	public void addAuto(Properties props);
	

}

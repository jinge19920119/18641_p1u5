package driver;

import server.BuildCarModelOptions;
/*
 * Name: Ge Jin
 * andrew id: gjin
 * date : jun 30, 2015
 */



public class DriverSer {
	public static void main(String[] args){
		BuildCarModelOptions model= new BuildCarModelOptions();//create an object and start it
		model.run();
	}
	

}

package adapter;

import scale.Scalable;

public class BuildAuto extends ProxyAutomobile implements CreateAuto, UpdateAuto, Scalable{


	
	
}